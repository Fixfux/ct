import sys,os,json
with open('/root/pro.json', 'r') as fp:
    user = json.load(fp)
letak = '/root/ss'
for bos in user["pro"]:
    bot = user["pro"][bos]["bot"]
    if user["pro"][bos]['pay'] == True:
        for n in bot:
            os.system('cp {}/default.py {}/{}.py'.format(letak,letak,bos+n))
            print("Primary bot {} updated".format(bos+n))
    else:
        pass